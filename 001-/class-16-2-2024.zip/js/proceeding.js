
// objects

// Operators
// ---
// + - / x %
// == != (===)

// Conditionals
// ---
// if
// if shorthand '' ? '' : ''
// if else
// switch

// Loops
// ---
// for
// foreach
// nested loops
// do while - while do


// Functions
// ---
